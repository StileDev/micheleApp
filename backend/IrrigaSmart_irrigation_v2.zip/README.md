# IrrigaSmart — App `irrigation` v2 (structure multi-parcelles, style WellAgriTech)

Cette version **remplace** l'app `irrigation` précédente (dashboard unique +
prévision + irrigation auto/manuel). Elle ne touche ni `accounts` ni
`administration`, qui restent identiques.

## Pourquoi ce n'est pas juste un ajout de fichiers

Le modèle `EtatIrrigation` de la v1 devient `EtatParcelle`, le champ `nom`
de `Parcelle` n'a plus de valeur par défaut, et deux nouveaux modèles
apparaissent (`Materiel`, `ActionLog`). Comme le projet est encore en
phase de développement, le plus simple est de repartir sur des migrations
propres plutôt que d'essayer de migrer les anciennes données :

```bash
# Remplace le contenu de irrigation/ par celui de ce zip, puis :
rm irrigation/migrations/0*.py
rm db.sqlite3          # si tu peux te permettre de perdre les données de test
python manage.py makemigrations irrigation
python manage.py migrate
```

Si tu as des données de test à garder, dis-le-moi et je peux te donner une
migration de transition à la place.

## Endpoints (préfixe `/irrigation/`)

| Action | Méthode | URL |
|---|---|---|
| Liste des parcelles | GET | `parcelles/` |
| Ajouter une parcelle | POST | `parcelles/` — `nom, superficie, culture, latitude, longitude` |
| Supprimer une parcelle | DELETE | `parcelles/<id>/` |
| Détail d'une parcelle (données temps réel + état + matériels) | GET | `parcelles/<id>/detail/` |
| Liste des matériels d'une parcelle | GET | `parcelles/<id>/materiels/` |
| Ajouter un matériel | POST | `parcelles/<id>/materiels/` — `nom` |
| Supprimer un matériel | DELETE | `parcelles/<id>/materiels/<materiel_id>/` |
| Envoyer une mesure (capteur IoT) | POST | `parcelles/<id>/mesures/` — `humidite_sol, temperature, humidite_air, ph_sol` |
| Démarrer l'irrigation | POST | `parcelles/<id>/irrigation/demarrer/` |
| Arrêter l'irrigation | POST | `parcelles/<id>/irrigation/arreter/` |
| Démarrer le drainage | POST | `parcelles/<id>/drainage/demarrer/` |
| Arrêter le drainage | POST | `parcelles/<id>/drainage/arreter/` |
| Historique des actions | GET | `parcelles/<id>/historique/` |
| Prévision des besoins en eau | GET | `parcelles/<id>/prevision/` |

## Sécurité

Toutes les vues filtrent systématiquement sur `request.user` via
`get_parcelle_du_user()` — un agriculteur ne peut jamais lire ou modifier
la parcelle d'un autre, même en devinant un ID.

## Ce qui n'est pas encore fait

- **Paramètres** (tuile du menu d'accueil) : rien de précis n'a été demandé
  sur ce que cet écran doit contenir, donc aucun endpoint n'a été créé.
  Dis-moi ce qu'il doit gérer (notifications, langue, unités...) et je
  l'ajoute.
- **Bouton chat flottant** : visible sur les captures WellAgriTech, mais
  aucune fonctionnalité de chat n'a été demandée jusqu'ici côté backend.
- **Sélecteur de langue (EN)** visible en haut de l'écran de connexion :
  c'est une fonctionnalité front (i18n Flutter), rien à faire côté serveur.

## Prochaine étape

Le zip Flutter doit être entièrement reconstruit pour coller à cette
nouvelle structure (liste de parcelles, écran détail avec plan des
capteurs, gestion des matériels, boutons Irrigation/Drainage séparés,
photo de fond sur connexion/inscription). Dis-moi quand tu veux que je
m'y mette.
