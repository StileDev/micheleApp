# IrrigaSmart — Apps Django (hors accounts)

Deux apps dans ce zip : `irrigation` (capteurs, tableau de bord, prévision,
contrôle de l'irrigation) et `administration` (gestion des utilisateurs,
réservée au rôle administrateur).

## 1. Installer les apps

Dans `settings.py` :

```python
INSTALLED_APPS = [
    ...
    'accounts',
    'irrigation',
    'administration',
]
```

## 2. Brancher les routes

Dans `urls.py` du projet :

```python
urlpatterns = [
    ...
    path('api/auth/', include('accounts.urls')),
    path('irrigation/', include('irrigation.urls')),
    path('api/admin/', include('administration.urls')),
]
```

## 3. Migrations

```bash
python manage.py makemigrations irrigation
python manage.py migrate
```

(`administration` n'a pas de modèle propre, donc pas de migration à générer
pour cette app.)

## À VÉRIFIER TOI-MÊME — dépendance au champ `role`

Ces deux apps supposent que ton modèle `User` (dans `accounts`) possède un
champ `role` avec les valeurs `"agriculteur"` ou `"administrateur"` :

- `administration/permissions.py` (`IsAdminRole`) vérifie `request.user.role`.
- Le Flutter attend ce champ dans `/api/auth/me/` et `/api/auth/register/`.

Si ton `accounts/models.py` actuel n'a pas ce champ, ajoute-le toi-même
(hors de ce zip, puisque tu m'as dit de ne pas toucher à `accounts`) :

```python
class User(AbstractBaseUser, PermissionsMixin):
    ...
    ROLE_CHOICES = [('agriculteur', 'Agriculteur'), ('administrateur', 'Administrateur')]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='agriculteur')
```

Puis ajoute `'role'` à `fields` dans `RegisterSerializer` et `UserSerializer`
(`accounts/serializers.py`), et migre.

## À AJUSTER — chemin des endpoints admin côté Flutter

Le zip Flutter précédent appelait `/api/auth/users/` pour la gestion des
utilisateurs (en supposant que ça vivrait dans `accounts`). Comme cette
logique est finalement dans `administration`, les routes réelles sont :

- `GET /api/admin/users/`
- `DELETE /api/admin/users/<id>/`

Il faut donc changer ces deux lignes dans `lib/services/admin_service.dart` :

```dart
final resp = await _client.dio.get('/api/admin/users/', ...);
...
await _client.dio.delete('/api/admin/users/$id/');
```

## Résumé des endpoints ajoutés

### irrigation/ (préfixe `/irrigation/`)
| Méthode | URL | Rôle |
|---|---|---|
| GET | `dashboard/` | Données du tableau de bord |
| POST | `mesures/` | Réception d'une mesure capteur |
| GET | `prevision/` | Prévision des besoins en eau (heuristique à remplacer par ton modèle, voir `services.py`) |
| GET | `etat/` | État actuel de l'irrigation |
| POST | `mode/` | Changer de mode (`auto` / `manuel`) |
| POST | `auto/toggle/` | Activer/couper l'irrigation automatique |
| POST | `declencher/` | Déclenchement manuel |
| POST | `arreter/` | Arrêt de l'irrigation en cours |

### administration/ (préfixe `/api/admin/`)
| Méthode | URL | Rôle |
|---|---|---|
| GET | `users/?search=...` | Liste des comptes actifs |
| DELETE | `users/<id>/` | Désactivation d'un compte (pas de suppression définitive) |

## Note sur la prévision

`irrigation/services.py` contient un calcul volontairement simple (seuil
d'humidité du sol) pour que l'endpoint réponde correctement pendant que
tu développes ta vraie logique de prévision — c'est explicitement
commenté dans le fichier. Comme c'est la partie centrale de ton thème
académique, ne livre pas cette version telle quelle : remplace le contenu
de `calculer_prevision()` par ton modèle, sans toucher aux vues.
