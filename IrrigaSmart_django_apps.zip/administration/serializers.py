from rest_framework import serializers
from django.contrib.auth import get_user_model

User = get_user_model()


class ManageUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'full_name', 'email', 'phone', 'role', 'is_active']
