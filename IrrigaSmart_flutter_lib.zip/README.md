# IrrigaSmart — Flutter (lib/)

## À faire avant de lancer l'app

1. `flutter pub get`
2. Vérifier `lib/services/api_client.dart` — la constante `baseUrl` doit pointer
   vers ton backend (adresse locale en dev, URL Render en test réel).
3. Le logo est déjà copié dans `assets/images/logo.jpeg`.

## Rôles utilisateur

Le champ `role` doit être renvoyé par le backend (`/api/auth/login/` via `/me/`,
et `/api/auth/register/`) avec l'une de ces deux valeurs :
- `"agriculteur"` → redirigé vers le tableau de bord agriculteur (FarmerShell)
- `"administrateur"` → redirigé vers le tableau de bord administrateur (AdminShell)

Si ton modèle Django utilise un champ différent (`is_staff`, `is_admin`...),
adapte `UserModel.fromJson` et les points où `role` est lu dans
`auth_service.dart` / `auth_provider.dart`.

## Endpoints attendus par l'app (à ajuster selon tes vraies routes)

### Authentification
| Action | Méthode | URL | Body |
|---|---|---|---|
| Inscription | POST | `/api/auth/register/` | `full_name, email, phone, password` → retourne `user{id, full_name, email, phone, role}, access, refresh` |
| Connexion | POST | `/api/auth/login/` | `email, password` → retourne `access, refresh` |
| Profil connecté | GET | `/api/auth/me/` | → retourne `id, full_name, email, phone, role` |
| Rafraîchir le token | POST | `/api/auth/token/refresh/` | `refresh` → retourne `access, refresh` |
| Déconnexion | POST | `/api/auth/logout/` | `refresh` |

### Agriculteur
| Action | Méthode | URL |
|---|---|---|
| Tableau de bord | GET | `/irrigation/dashboard/` |
| Prévision des besoins en eau | GET | `/irrigation/prevision/` |
| État de l'irrigation | GET | `/irrigation/etat/` |
| Changer de mode | POST | `/irrigation/mode/` — body `{mode: "auto" \| "manuel"}` |
| Activer/désactiver l'auto | POST | `/irrigation/auto/toggle/` — body `{actif: bool}` |
| Déclencher manuellement | POST | `/irrigation/declencher/` — body `{duree_minutes: int}` |
| Arrêter l'irrigation | POST | `/irrigation/arreter/` |

### Administrateur
| Action | Méthode | URL |
|---|---|---|
| Liste des utilisateurs | GET | `/api/auth/users/?search=...` |
| Désactiver un utilisateur | DELETE | `/api/auth/users/<id>/` |

Les formats JSON attendus par chaque écran sont détaillés dans
`lib/models/` (un fichier par type de donnée : `dashboard_data.dart`,
`prevision_data.dart`, `manage_user_model.dart`). Si tes endpoints renvoient
des noms de champs différents, c'est uniquement dans ces fichiers `fromJson`
qu'il faut ajuster le mapping — le reste de l'app n'a pas besoin de changer.

## Structure

```
lib/
  core/            -> variables globales (navigatorKey, authProvider)
  theme/           -> couleurs et styles de texte
  models/          -> structures de données (parsing JSON)
  services/        -> appels réseau (Dio)
  providers/       -> état partagé (Provider / ChangeNotifier)
  widgets/         -> composants réutilisables
  screens/
    splash_screen.dart
    login_screen.dart
    register_screen.dart
    farmer/        -> tableau de bord, prévision, irrigation
    admin/         -> gestion des utilisateurs
```

## Ce qui n'est pas fait volontairement

- Mot de passe oublié (mis de côté sur ta demande).
- Ajout d'utilisateur depuis le dashboard administrateur (pour l'instant,
  seule la désactivation est branchée — l'ajout se ferait via le même
  écran d'inscription si besoin).
